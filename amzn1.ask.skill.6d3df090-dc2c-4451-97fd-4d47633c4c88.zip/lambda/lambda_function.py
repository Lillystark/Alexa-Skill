# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

import random

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

naturefacts = [
    "Mount Musala, standing at 2,925 m, is the highest point in Bulgaria.",
    "The lowest point in Bulgaria is in the Black Sea.",
    "Bulgaria ranks as the third most biodiverse Eastern European country. It has over 3,500 vascular plant species and almost 415 bird species.",
    "The two major mountain ranges in Bulgaria are the Balkan Mountains and the Rhodope Mountains.",
    "Forests in Bulgaria constitute one-third of the country's territory."
    ]

historyfacts = [
    "The legendary Thracian singer, Orpheus, spent his life in ancient Bulgaria. Orpheus is the son of Oeagros, God of the River.",
    "In the 1980s, Bulgaria was the second-largest wine producer in the world.",
    "The oldest processed gold in the world is found in Varna in Bulgaria. The golden artifacts were believed to be 7,000 years old.",
    "Bulgaria is the only European country that hasn't changed its name since the year it was established.",
    "No army in the world has ever captured a Bulgarian flag in battle.",
    "Bulgaria was one of the two countries that protected their Jewish inhabitants from being sent to the Nazi concentration camps.",
    "Despite being located in the heart of Europe, Bulgaria has never been colonized."
    ""
    ]

culturefacts = [
    "The capital of Bulgaria, Sofia, has a motto which goes as “Raste no ne stare”. In English, it means “grows but does not age”.",
    "On Jordan's Day in Bulgaria, there's one custom that involves a priest throwing a cross into the river. The man who can retrieve the cross is said to be rewarded with good health and happiness.",
    "Name Day is a celebration in Bulgaria by those who have the name of a Saint. The person with the Saint's name invites guests at home or at a restaurant. Name days are widely celebrated by locals, even more than their own birthdays.",
    "The longest Bulgarian word is composed of 39 letters. It means “do not perform actions against the constitution”.",
    "Bulgarians shake their head when they mean to say “yes” and nod when they want to say “no”.",
    "Every first of March, Bulgarians celebrate a unique holiday known as Baba Marta (Grandmother March). Locals exchange martenitsas or tassels of white and red yarn."
    ]

foodfacts = [
    "Kozunak is a traditional braided sweet bread. It is a favorite among Bulgarians, especially during Easter.",
    "Shopska salad, also known as Bulgarian salad, won as best dish in Europe in a contest organized by the European Parliament.",
    "Rakia is an alcoholic drink made from fermented pears, grapes, or apricots",
    "The unique consistency of Bulgarian yogurt is because of the Lactobacillus Bulgaricus which cannot be found anywhere else."
    ]

randomstarts = [
    "Okay.",
    "Great.",
    "No problem."
    ]

randomends = [
    "Would you like another fact?",
    "Let me know if you would like another fact.",
    "How about another fact?"
    ]

class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Welcome to Facts about Bulgaria! You can choose between history, culture, cuisine and nature facts. What type of fact would you like to hear?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class NatureFactIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("NatureFactIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = random.choice(randomstarts) + " " + random.choice(naturefacts) + " " + random.choice(randomends)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class HistoryFactIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HistoryFactIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = random.choice(randomstarts) + " " + random.choice(historyfacts) + " " + random.choice(randomends)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class CultureFactIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CultureFactIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = random.choice(randomstarts) + " " + random.choice(culturefacts) + " " + random.choice(randomends)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class FoodFactIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("FoodFactIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = random.choice(randomstarts) + " " + random.choice(foodfacts) + " " + random.choice(randomends)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class AnotherFactIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AnotherFactIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = random.choice(randomstarts) + " " + "What type of fact would you like to hear this time?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello, how can I help you? Would you like me to tell you a fact about Bulgaria?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class FallbackIntentHandler(AbstractRequestHandler):
    """Single handler for Fallback Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        logger.info("In FallbackIntentHandler")
        speech = "Hmm, I'm not sure. You can say Hello or Help. What would you like to do?"
        reprompt = "I didn't catch that. What can I help you with?"

        return handler_input.response_builder.speak(speech).ask(reprompt).response

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(NatureFactIntentHandler())
sb.add_request_handler(HistoryFactIntentHandler())
sb.add_request_handler(CultureFactIntentHandler())
sb.add_request_handler(FoodFactIntentHandler())
sb.add_request_handler(AnotherFactIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()